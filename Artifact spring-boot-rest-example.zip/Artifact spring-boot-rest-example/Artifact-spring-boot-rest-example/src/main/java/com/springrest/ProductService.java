package com.springrest;

import java.util.ArrayList;

import java.util.List;
import org.springframework.stereotype.Service;
import com.springrest.Product;

@Service
public class ProductService implements IProductService {
	List<Product> List=new ArrayList<Product>();
	Product Product=new Product();

    @Override
    public List<Product> findAll() {
//creating an object of ArrayList  
        ArrayList<Product> products = new ArrayList<Product>();
//adding products to the List  
        products.add(new Product(100, "Mobile", "CLK98123", 9000.00, 6));
        products.add(new Product(101, "Smart TV", "LGST09167", 60000.00, 3));
        products.add(new Product(102, "Washing Machine", "38753BK9", 9000.00, 7));
        products.add(new Product(103, "Laptop", "LHP29OCP", 24000.00, 1));
        products.add(new Product(104, "Air Conditioner", "ACLG66721", 30000.00, 5));
        products.add(new Product(105, "Refrigerator ", "12WP9087", 10000.00, 4));
        products.add(new Product(107, "Laptop4", "LHP29OCP", 50000.00, 1));
        products.add(new Product(108, "car", "ACLG66721", 300000.00, 9));
        products.add(new Product(109, "BIke", "12WP9087", 100000.00, 9));
//returns a list of product  
        return products;
    }
    @Override
    public Product getsingleproduct(String productname) {
    	
    	return this.List.stream().filter((Product)->Product.getPname().equals(productname)).findAny().orElse(null);
    }
};











