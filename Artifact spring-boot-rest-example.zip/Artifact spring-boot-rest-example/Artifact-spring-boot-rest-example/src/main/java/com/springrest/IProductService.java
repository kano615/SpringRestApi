package com.springrest;

import java.util.List;

public interface IProductService {
    List<Product> findAll();  
    Product getsingleproduct(String productname);
}
