package com.springrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtifactSpringBootRestExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
